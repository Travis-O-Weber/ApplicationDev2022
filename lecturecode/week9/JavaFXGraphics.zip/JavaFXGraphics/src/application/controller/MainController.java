package application.controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.transform.Translate;

public class MainController implements EventHandler<ActionEvent>{

	// TODO: add a Circle to the fxml file and add object
	@FXML 
	Circle circleBlue;

	@Override
	public void handle(ActionEvent event) {

		//	TODO: get the circle location
		double location = circleBlue.getCenterX();		

		//	TODO: create a Translate object
		Translate t = new Translate();

		// TODO: set the transform x to a new value
		t.setX(location - 50);

		// TODO: apply the transform to the circle
		circleBlue.getTransforms().addAll(t);


		// TODO: change the circle color
		circleBlue.setFill(Color.color(0.1, 0.2, 0.3));
		//	Other way for changing color	
		//		Color color = Color.rgb(110, 250, 90);
		//		
		//		circleBlue.setFill(color);
		//		

		/* Color
		-  RGB : R = , G:, B: 0 -255
		   0/255 = 0        255/255 = 1

		 */


	}




}
