package application.model;

public class PDFBook extends EBook{
	
	public PDFBook(String title) {
		super(title);
	}

	@Override
	public String readBook() {
		return "";
	}


}
