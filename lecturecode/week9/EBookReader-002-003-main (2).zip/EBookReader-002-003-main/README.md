# EBookReader-002-003
In-class code for sections 002 and 003
