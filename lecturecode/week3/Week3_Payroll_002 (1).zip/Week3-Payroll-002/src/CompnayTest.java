/**
 * 
 * @author CS 3443
 *
 */
public class CompnayTest {
	
	public static void main(String[] args) {
		
		// Create a company
		Company ourCompany = new Company("CS Company", 10);
		
		// Add employees
				
		HourlyEmployee emp1 = new HourlyEmployee("Alex", "Software Engineer", "09-07-2022", 40, 20.5);
		
		Employee emp2 = new SalaryEmployee("Amanda", "Software Engineer", "09-07-2022", 80000);
		
		ourCompany.addEmployee(emp1);
		ourCompany.addEmployee(emp2);
		
	}

}
