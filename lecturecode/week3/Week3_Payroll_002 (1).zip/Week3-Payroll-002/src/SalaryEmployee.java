
public class SalaryEmployee {
	
	

}
