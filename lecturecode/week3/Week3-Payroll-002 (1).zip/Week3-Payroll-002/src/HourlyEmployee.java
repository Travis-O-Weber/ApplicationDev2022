
public class HourlyEmployee extends Employee {


	// Add Attributes
	private double pay;
	private double hrsPerWeek;


	public HourlyEmployee(String name, String title, String hireDate, double pay, double hrsPerWeek) {
		super(name, title, hireDate);
		this.pay = pay; 
		this.hrsPerWeek = hrsPerWeek;
	}



}
