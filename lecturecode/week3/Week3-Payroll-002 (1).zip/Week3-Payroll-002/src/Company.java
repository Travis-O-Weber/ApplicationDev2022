import java.util.ArrayList;

/**
 * 
 * @author CS 3443
 *
 */
public class Company {

	// Add Attributes
	private String name;
	private String type;
	private ArrayList<Employee> employees;
	
	// Add Constructors
	public Company(String name, int numOfEmployees) {
		this.name = name;
		this.employees = new ArrayList<Employee>();		
	}

	
	// Add toString()
	
	// Add Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(ArrayList<Employee> employees) {
		this.employees = employees;
	}

	public void addEmployee(Employee newEmployee) {		
		this.employees.add(newEmployee);	
	}
}
