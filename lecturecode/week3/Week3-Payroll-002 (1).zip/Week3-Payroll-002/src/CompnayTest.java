import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * @author CS 3443
 *
 */
public class CompnayTest {
	
	public static void main(String[] args) throws FileNotFoundException {
		
		// Create a company
		Company ourCompany = new Company("CS Company", 10);
		
		// Add employees
				
		HourlyEmployee emp1 = new HourlyEmployee("Alex", "Software Engineer", "09-07-2022", 40, 20.5);
		
		Employee emp2 = new SalaryEmployee("Amanda", "Software Engineer", "09-07-2022", 80000);
		
		ourCompany.addEmployee(emp1);
		ourCompany.addEmployee(emp2);
		
		// read input from console
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter name");
//		String name = scan.next();
//		System.out.println("Enter title");
//		String title = scan.next();
//		System.out.println("Enter salary");
//		double pay = scan.nextDouble();
//		
//		System.out.println("name " + name);
//		System.out.println("title " + title);
//		System.out.println("salary" + pay);
		
		
		File inputFile = new File("data/employee_info.csv");
		Scanner scan = new Scanner (inputFile);
		String name = scan.next();
		String title = scan.next();
		double pay = scan.nextDouble();

		System.out.println("name " + name);
		System.out.println("title " + title);
		System.out.println("salary" + pay);
	
	}

}
