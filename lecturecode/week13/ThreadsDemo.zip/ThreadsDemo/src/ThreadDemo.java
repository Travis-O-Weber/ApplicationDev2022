//class MyTask extends Thread{
//	void executeTask() {
//		for(int doc = 1; doc < 10; doc++)
//			System.out.println("MyTaskPrint" + doc);
//	}
//	@Override
//	public void run() {
//		executeTask();
//	}
//}

class MyTask implements Runnable{
	void executeTask() {
		for(int doc = 1; doc < 10; doc++)
			System.out.println("MyTaskPrint" + doc);
	}
	
	@Override
	public void run() {
		executeTask();
	}
}

public class ThreadDemo {

	public static void main(String[] args) {
		
		System.out.println("== Main Thread Started ==");
		
		for(int doc = 1; doc < 10; doc++)
			System.out.println("MainPrint" + doc);
		
		
		MyTask task = new MyTask();
		Thread th = new Thread(task);
		th.start();
		//task.start();
		//task.executeTask();
			
		System.out.println("== Main Thread Finished ==");
		
	

	}

}
