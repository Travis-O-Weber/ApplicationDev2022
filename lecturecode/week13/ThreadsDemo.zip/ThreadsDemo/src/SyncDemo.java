
public class SyncDemo {

	public static void main(String[] args) {
		System.out.println("== Main Thread Started ==");

		Printer printer = new Printer();

		MyThread m = new MyThread(printer);
		YourThread y = new YourThread(printer);


		m.start();
		//		try {
		//			m.join();
		//
		//		} catch (InterruptedException e) {
		//			e.printStackTrace();
		//		}
		y.start();
		//		try {
		//			y.join();
		//
		//		} catch (InterruptedException e) {
		//			e.printStackTrace();
		//		}

		System.out.println("== Main Thread Finished ==");

	}

}

class Printer{

	public synchronized void printDocument(int numCopies, String docName) {

		for (int i = 1; i <= numCopies; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(">> Printing " + docName + " " + i);
		}
		System.out.println(docName + " is done ...");
	}

}

class MyThread extends Thread{

	private Printer pRef;

	MyThread (Printer p){
		pRef = p;
	}

	@Override
	public void run() {
		pRef.printDocument(20, "MyProfile.pdf");		
	}
}

class YourThread extends Thread{

	private Printer pRef;

	YourThread (Printer p){
		pRef = p;
	}

	@Override
	public void run() {
		pRef.printDocument(15, "YourProfile.pdf");		
	}
}
