package application.controller;

import application.Main;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class MainController implements EventHandler<ActionEvent>{
	
	@FXML
	Label lblDirCheck;

	@Override
	public void handle(ActionEvent event) {
		// TODO Auto-generated method stub
		System.out.println("Hello !");
		// check path
		
		// if invalid update label
		lblDirCheck.setText("Invalid Library!");
				
		
		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("../view/Library.fxml"));

			Scene scene = new Scene(loader.load());

			Main.stage.setScene(scene);
			Main.stage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
			
	}
	

}
