package application.controller;

import java.io.File;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class LibraryController implements EventHandler<ActionEvent>{
	
	@FXML
	ImageView ivBookCover;

	@Override
	public void handle(ActionEvent event) {
		
		// check source event
		Button btBook = (Button) event.getSource();		
		
		System.out.println("The event source id is: " + btBook.getId());
		
		
		if(btBook.getId() != null && btBook.getId().equals("btBook1ID")) {
			System.out.println("Book One is Loading ...");			
			
			// display image of book 1
			
			// Use an image from the images folder in your project
//			Image img = new Image("file:images/2020-09-18.jpg");
//			ivBookCover.setImage(img);
			
			
			// Use an image that the user selects
			FileChooser fileChooser = new FileChooser();
			
			File imgFile = fileChooser.showOpenDialog(null);
			
			ivBookCover.setImage(new Image(imgFile.toURI().toString()));
			
			System.out.println(imgFile.toString());
			
			System.out.println(imgFile.toURI().toString());
			
		}
		
		if(btBook.getText().equals("Book 2")) {
			System.out.println("Book Two is Loading ...");			
			
			// TODO: display image of book 2
		}
				
	}
	
	// method assigned to Book 1 button
	public void handleBookOne(ActionEvent event) {
		System.out.println("Book One is Loading ...");
		
	}
	
	// method assigned to Book 2 button
	public void handleBookTwo(ActionEvent event) {
		System.out.println("Book Two is Loading ...");
		
	}
	
}
