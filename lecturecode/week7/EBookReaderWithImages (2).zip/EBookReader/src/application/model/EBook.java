package application.model;

public abstract class EBook {
	
	
	
	

}
