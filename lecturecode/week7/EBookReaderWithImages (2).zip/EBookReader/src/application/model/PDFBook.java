package application.model;

public class PDFBook extends EBook{
	
	
	
	

}
