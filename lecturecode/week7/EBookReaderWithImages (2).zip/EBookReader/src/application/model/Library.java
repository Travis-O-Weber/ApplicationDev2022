package application.model;

public class Library {

}
