package application.model;

public class TxtBook extends EBook {
	
	
	

}
