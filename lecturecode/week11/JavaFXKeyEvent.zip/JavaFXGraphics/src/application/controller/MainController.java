package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.transform.Translate;

public class MainController implements Initializable, EventHandler<KeyEvent>{
	
	@FXML
	Circle circleBlue;

	/*
	 *  references: 
	 *  https://stackoverflow.com/questions/24125916/javafx-key-pressed-event-for-scene-not-executed-if-there-is-a-focused-component
	 *  
	 */
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		circleBlue.setFocusTraversable(true);
	}

	@Override
	public void handle(KeyEvent event) {

		System.out.println(event.getCode());

		double location = circleBlue.getCenterX();		

		Translate t = new Translate();

		if(event.getCode() == KeyCode.UP) {
			t.setY(location - 50);
		}
		if(event.getCode() == KeyCode.DOWN) {
			t.setY(location + 50);
		}
		if(event.getCode() == KeyCode.LEFT) {
			t.setX(location - 50);
		}
		if(event.getCode() == KeyCode.RIGHT) {
			t.setX(location + 50);
		}
		circleBlue.getTransforms().addAll(t);
		circleBlue.setFill(Color.color(0.1, 0.2, 0.3));
	}

	

}
