package genericclasses;

/**
 * A PairOfDifferentTypes object stores a pair of objects. The type parameter S
 * is for the first object. The type parameter T is for the second object.
 * 
 * @author Tom Bylander
 */
public class PairOfDifferentTypes<S, T> {
    // Note the use of S and T.
    private S first;
    private T second;

    /**
     * Stores two objects in instance variables. S and T will be substituted
     * with the type arguments in the declaration, e.g.;
     * 
     * PairOfDifferentTypes<Integer,String> pair = 
     *     new PairOfDifferentTypes<Integer,String>(13, "thirteen");
     * 
     * @param object1
     * @param object2
     */
    public PairOfDifferentTypes(S object1, T object2) {
        first = object1;
        second = object2;
    }

    /**
     * Note the use of the type parameter S.
     * 
     * @return the first object
     */
    public S getFirst() {
        return first;
    }

    /**
     * Note the use of the type parameter T.
     * 
     * @return the second object
     */
    public T getSecond() {
        return second;
    }
}
