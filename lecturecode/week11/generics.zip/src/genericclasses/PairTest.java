package genericclasses;
public class PairTest {
    public static void main(String[] args) {
        // Need to cast to operate on the Integer objects.
        PairOfObjects pair1 = new PairOfObjects(123, 456);
        // This doesn't work.
        // System.out.println(pair1.getFirst() + pair1.getSecond());
        System.out.println((Integer) pair1.getFirst() + (Integer) pair1.getSecond());

        // Need to cast to operate on the String objects.
        PairOfObjects pair2 = new PairOfObjects("123", "456");
        // This doesn't work.
        // System.out.println(pair2.getFirst() + pair2.getSecond());
        System.out.println((String) pair2.getFirst() + (String) pair2.getSecond());
        
        // To avoid casting without generics,
        // different classes are needed for different types. 
        PairOfIntegers pair3 = new PairOfIntegers(123, 456);
        System.out.println(pair3.getFirst() + pair3.getSecond());
        PairOfStrings pair4 = new PairOfStrings("123", "456");
        System.out.println(pair4.getFirst() + pair4.getSecond());
        
        // With generics, a single class can be used to store a pair
        // of values with the same type.
        PairOfSameType<Integer> pair5 = new PairOfSameType<Integer>(123, 456);
        System.out.println(pair5.getFirst() + pair5.getSecond());
        PairOfSameType<String> pair6 = new PairOfSameType<String>("123", "456");
        System.out.println(pair6.getFirst() + pair6.getSecond());

        // What if we want a pair of different types?
        // Without generics, we need to cast to operate on the specific types.
        PairOfObjects pair7 = new PairOfObjects(123, 0.456);
        // This doesn't work.
        // System.out.println(pair7.getFirst() + pair7.getSecond());
        System.out.println((Integer) pair7.getFirst() + (Double) pair7.getSecond());

        // Or without generics, we need a class for the specific pair of types
        PairOfIntegerAndDouble pair8 = new PairOfIntegerAndDouble(123, 0.456);
        System.out.println(pair8.getFirst() + pair8.getSecond());

        // With generics, a single class can be used to store a pair
        // of values with different types.
        PairOfDifferentTypes<Integer,Double> pair9 = 
                new PairOfDifferentTypes<Integer,Double>(123, 0.456);
        System.out.println(pair9.getFirst() + pair9.getSecond());
    }
}
