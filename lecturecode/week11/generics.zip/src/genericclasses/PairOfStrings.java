package genericclasses;
/**
 * A PairOfStrings object stores a pair of strings.
 * 
 * @author Tom Bylander
 */
public class PairOfStrings {
    private String first, second;

    /**
     * Stores two strings in fields
     * @param string1
     * @param string2
     */
    public PairOfStrings(String string1, String string2) {
        first = string1;
        second = string2;
    }

    /**
     * @return the first string
     */
    public String getFirst() {
        return first;
    }

    /**
     * @return the second string
     */
    public String getSecond() {
        return second;
    }
}
