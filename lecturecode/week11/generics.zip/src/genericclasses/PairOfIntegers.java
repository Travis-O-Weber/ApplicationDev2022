package genericclasses;
/**
 * A PairOfIntegers object stores a pair of Integers.
 * 
 * @author Tom Bylander
 */
public class PairOfIntegers {
    private Integer first, second;

    /**
     * Stores two numbers in fields
     * @param integer1
     * @param integer2
     */
    public PairOfIntegers(Integer integer1, Integer integer2) {
        first = integer1;
        second = integer2;
    }

    /**
     * @return the first integer
     */
    public Integer getFirst() {
        return first;
    }

    /**
     * @return the second integer
     */
    public Integer getSecond() {
        return second;
    }
}
