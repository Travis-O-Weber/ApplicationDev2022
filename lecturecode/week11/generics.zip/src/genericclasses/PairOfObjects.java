package genericclasses;
/**
 * A PairOfObjects object stores a pair of objects.
 * 
 * @author Tom Bylander
 */
public class PairOfObjects {
    private Object first, second;

    /**
     * Stores two objects in fields
     * @param object1
     * @param object2
     */
    public PairOfObjects(Object object1, Object object2) {
        first = object1;
        second = object2;
    }

    /**
     * @return the first object
     */
    public Object getFirst() {
        return first;
    }

    /**
     * @return the second object
     */
    public Object getSecond() {
        return second;
    }
}
