package genericclasses;
/**
 * A PairOfIntegerAndDouble object stores an Integer and a Double.
 * 
 * @author Tom Bylander
 */
public class PairOfIntegerAndDouble {
    private Integer first;
    private Double second;

    /**
     * Stores an Integer and a Double in the fields
     *  
     * @param first
     * @param second
     */
    public PairOfIntegerAndDouble(Integer first, Double second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Return the first field.
     * 
     * @return the Integer
     */
    public Integer getFirst() {
        return first;
    }

    /**
     * Return the second field.
     * 
     * @return the Double
     */
    public Double getSecond() {
        return second;
    }
}
