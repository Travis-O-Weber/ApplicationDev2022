package genericclasses;
/**
 * A PairOfSameType object stores a pair of objects generic type T. T is specified when
 * declaring the PairOfSameType variable.
 * 
 * @author Tom Bylander
 */
public class PairOfSameType<T> {
    // Note the use of the generic parameter T.
    private T first, second;

    /**
     * Stores two objects in instance variables. The type parameter T will be
     * substituted with the type argument in the declaration, e.g.;
     * 
     * PairOfSameType<String> pair = 
     *     new PairOfSameType<String>("Hello", "World");
     * 
     * @param object1
     * @param object2
     */
    public PairOfSameType(T object1, T object2) {
        first = object1;
        second = object2;
    }

    /**
     * Note the use of the type parameter T.
     * 
     * @return the first object
     */
    public T getFirst() {
        return first;
    }

    /**
     * Note the use of the type parameter T.
     * 
     * @return the second object
     */
    public T getSecond() {
        return second;
    }
}
