package genericinterfaces;
/**
 * A City object stores city and state Strings. The City class implements the
 * Comparable interface. The generic argument ensures that City objects can't be
 * compared to other objects.
 * 
 * @author Tom Bylander
 */
public class City implements Comparable<City> {
    public String city, state;

    /**
     * Store the names of the city and the state.
     */
    public City(String c, String s) {
        city = c;
        state = s;
    }

    /**
     * @return the name of the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @return the name of the state
     */
    public String getState() {
        return state;
    }

    /**
     * Return a String in the format "city, state".
     */
    public String toString() {
        return String.format("[%s, %s]", city, state);
    }

    /**
     * Compare cities using the city name as the primary key and the state name
     * as the secondary key.  Maybe compareToIgnoreCase should be used.
     */
    public int compareTo(City other) {
        if (this.city.compareTo(other.city) < 0)
            return -1;
        else if (this.city.compareTo(other.city) > 0)
            return 1;
        else
            return (this.state.compareTo(other.state));
    }
}
