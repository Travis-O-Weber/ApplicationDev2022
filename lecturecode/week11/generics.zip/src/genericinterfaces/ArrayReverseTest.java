package genericinterfaces;
import java.util.*;

/**
 * Use the cities from CityTest to test ArrayReverse.
 * 
 * @author Tom Bylander
 */
public class ArrayReverseTest {
    /**
     * main method
     */
    public static void main(String[] args) {
        City[] cities = new City[CityTest.cityNames.length];
        for (int i = 0; i < cities.length; i++) {
            cities[i] = new City(CityTest.cityNames[i], CityTest.stateNames[i]);
        }
        
        Arrays.sort(cities);
            
        Iterator<City> iterator = new ArrayReverse<City>(cities);
        while (iterator.hasNext()) {
            City city = iterator.next();
            System.out.print(city + "; ");
        }
        System.out.println();
        
        Arrays.sort(cities, new CityComparator());
        
        Iterable<City> iterable = new ArrayReverse<City>(cities);
        for (City city : iterable) {
            System.out.print(city + "; ");
        }
        System.out.println();
    }
}
