package genericinterfaces;
import java.util.*;

/**
 * This class can be used to compare cities using the state as the primary key.
 * 
 * 
 * @author Tom Bylander
 */
public class CityComparator implements Comparator<City> {
    /**
     * Compare two cities using the state as the primary key and the city as the
     * secondary key.
     */
    public int compare(City city1, City city2) {
        String state1 = city1.getState();
        String state2 = city2.getState();
        if (state1.compareTo(state2) < 0) {
            return -1;
        } else if (state1.compareTo(state2) > 0) {
            return 1;
        }
        String c1 = city1.getCity();
        String c2 = city2.getCity();
        
        return (c1.compareTo(c2));
    }
}
