package genericinterfaces;
import java.util.*;

/**
 * A class for looping thru an array in reverse. The type parameter T is the
 * type of object in the array
 * 
 * @author Tom Bylander
 */
public class ArrayReverse<T> implements Iterator<T>, Iterable<T> {
    // Note the use of the type parameter T both in the implements
    // clause above and the instance variable below.
    private T[] array;
    private int nextIndex;

    /**
     * Store the array and set nextIndex to the last index of the array.
     * Note the use of the type parameter T.
     * 
     * @param array
     */
    public ArrayReverse(T[] array) {
        this.array = array;
        nextIndex = array.length - 1;
    }

    /**
     * Return true if the next index to be accessed is a valid index.
     */
    public boolean hasNext() {
        return (nextIndex >= 0 && nextIndex < array.length);
    }

    /**
     * Return the next value in the array, going in reverse. See the
     * documentation about the exception.  Note the use of T.
     */
    public T next() {
        if (nextIndex < 0) {
            throw new NoSuchElementException();
        }
        T result = array[nextIndex];
        nextIndex--;
        return result;
    }

    /**
     * See documentation. This is what you are supposed to do if removal can't
     * be done or is, for some other reason, not permitted.
     */
    public void remove() {
        throw new UnsupportedOperationException();
    }

    /**
     * To be safe, this returns a brand new Iterator.  This iterator
     * might already be used up.  This also allows the same ArrayReverse
     * object to be used in multiple for-each loops.
     */
    public Iterator<T> iterator() {
        return new ArrayReverse<T>(array);
    }
}
