package genericinterfaces;

import java.util.*;
import java.util.function.*;

/**
 * Test the City and CItyComparator classes. Use the static sort method from the
 * Collections class to sort cities two different ways.
 * 
 * @author Tom Bylander
 */
public class CityTest {
    public static final String[] cityNames = { "Austin", "Boise", "Denver",
            "Santa Fe", "New Orleans", "Oklahoma City", "Kansas City",
            "Kansas City", "Chicago", "Los Angeles" };

    public static final String[] stateNames = { "Texas", "Idaho", "Colorado",
            "New Mexico", "Louisiana", "Oklahoma", "Missouri", "Kansas",
            "Illinois", "California" };

    /**
     * Main method
     */
    public static void main(String[] args) {
        useCityAsTypeArgument();
        // useLambdaExpressions();
        useCityWithoutGenerics();
    }

    /**
     * Using ArrayList<City>
     */
    public static void useCityAsTypeArgument() {
        System.out.println("Use City as generic type argument");

        ArrayList<City> cities = new ArrayList<City>();
        for (int i = 0; i < cityNames.length; i++) {
            City city = new City(cityNames[i], stateNames[i]);
            cities.add(city);
        }

        // Java will detect this error at compile time.
        // cities.add(13);

        System.out.println("Sort using compareTo in City class:");
        Collections.sort(cities);
        System.out.println(cities);

        System.out.println("Sort using CityComparator class:");
        Collections.sort(cities, new CityComparator());
        System.out.println(cities);
    }

    /**
     * Using ArrayList without any type argument.
     */
    public static void useCityWithoutGenerics() {
        System.out.println("\nUse City without type argument");

        ArrayList cities = new ArrayList();
        for (int i = 0; i < cityNames.length; i++) {
            City city = new City(cityNames[i], stateNames[i]);
            cities.add(city);
        }

        // Oops, Java allows any object to be added to cities.
        cities.add(13);

        // This will result in a runtime error.
        System.out.println("Sort using compareTo in City class:");
        Collections.sort(cities);
        System.out.println(cities);

        System.out.println("Sort using CityComparator class:");
        Collections.sort(cities, new CityComparator());
        System.out.println(cities);
    }

    /**
     * Examples of lambda expressions.
     */
    public static void useLambdaExpressions() {
        System.out.println("\nUse lambda expressions to implement Comparator");

        ArrayList<City> cities = new ArrayList<City>();
        for (int i = 0; i < cityNames.length; i++) {
            City city = new City(cityNames[i], stateNames[i]);
            cities.add(city);
        }

        Collections.sort(cities, (city1, city2) -> {
            String state1 = city1.getState();
            String state2 = city2.getState();
            if (state1.compareTo(state2) != 0) {
                return -1;
            } else if (state1.compareTo(state2) > 0) {
                return 1;
            }
            String c1 = city1.getCity();
            String c2 = city2.getCity();
            return c1.compareTo(c2);

        });
        System.out.println(cities);

        Collections.shuffle(cities);
        Collections.sort(cities,
                (city1, city2) -> firstNonZero(
                        city1.getState().compareTo(city2.getState()),
                        city1.getCity().compareTo(city2.getCity())));
        System.out.println(cities);

        Collections.shuffle(cities);
        Collections.sort(cities,
                (city1, city2) -> eval((a, b) -> (a != 0) ? a : b,
                        city1.getState().compareTo(city2.getState()),
                        city1.getCity().compareTo(city2.getCity())));
        System.out.println(cities);

        Collections.shuffle(cities);
        Collections.sort(cities,
                (city1, city2) -> ((IntBinaryOperator) (a, b) -> (a != 0) ? a
                        : b).applyAsInt(
                                city1.getState().compareTo(city2.getState()),
                                city1.getCity().compareTo(city2.getCity())));
        System.out.println(cities);

    }

    public static int eval(IntBinaryOperator o, int a, int b) {
        return o.applyAsInt(a, b);
    }

    public static int firstNonZero(int... values) {
        for (int x : values) {
            if (x != 0)
                return x;
        }
        return 0;
    }
}
