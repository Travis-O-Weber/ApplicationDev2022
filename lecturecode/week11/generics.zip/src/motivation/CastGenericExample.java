package motivation;
import java.util.*;

/**
 * This shows an example of casts vs. generics to access values in ArrayLists.
 * 
 * @author Tom Bylander
 */
public class CastGenericExample {
    public static final Integer[] values = { 2, 3, 5, 7, 11, 13, 17, 19 };

    public static void main(String[] args) {
        // Without generics, you need casts to use values in ArrayLists.
        ArrayList ungeneric = new ArrayList();
        for (Integer val : values)
            ungeneric.add(val);
        Integer sum1 = 0;
        // Can't use Integer here
        for (Object val : ungeneric) {
            // Have to cast to Integer
            sum1 += (Integer) val;
        }
        System.out.printf("Sum is %d\n", sum1);

        // With generics, Java knows Integers are coming out of the ArrayList.
        ArrayList<Integer> generic = new ArrayList<Integer>();
        for (Integer val : values)
            generic.add(val);
        Integer sum2 = 0;
        for (Integer val : generic) {
            sum2 += val;
        }
        System.out.printf("Sum is %d\n", sum2);
    }
}
