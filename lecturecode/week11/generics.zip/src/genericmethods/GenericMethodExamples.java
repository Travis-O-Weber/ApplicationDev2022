package genericmethods;
import java.util.*;

/**
 * Demostrate some generic methods.
 * 
 * @author Tom Bylander
 */
public class GenericMethodExamples {
    /**
     * Test the generic methods randomElement and lessThan
     */
    public static void main(String[] args) {
        Integer[] intArray = { 1, 3, 5, 7, 9, 0, 2, 4, 6, 8 };
        String[] stringArray = { "xx", "yy", "zz", "aa", "bb", "cc" };

        // Compare to
        // Integer rint = randomInteger(intArray);
        Integer rint = randomElement(intArray);
        System.out.printf("randomElement(%s) = %d\n",
                Arrays.toString(intArray), rint);

        // Compare to
        // String rstring = randomString(stringArray);
        String rstring = randomElement(stringArray);
        System.out.printf("randomElement(%s) = %s\n",
                Arrays.toString(stringArray), rstring);

        // Test 5 against the elements in the intArray.
        for (Integer n : intArray) {
            // Compare to
            // boolean b = lessThanInteger(5, n);
            boolean b = lessThan(5, n);
            System.out.printf("lessThan(%d, %d) = %b\n", 5, n, b);
        }

        // Test xx against the elements in the intArray.
        for (String s : stringArray) {
            // Compare to
            // boolean b = lessThanString("xx", s);
            boolean b = lessThan("xx", s);
            System.out.printf("lessThan(%s, %s) = %b\n", "xx", s, b);
        }

        // Java finds a compiler error in this line.
        // boolean b = lessThan(5, "xx");
    }

    /**
     * Return a random Integer from the Integer array. 
     */
    public static Integer randomInteger(Integer[] array) {
        Random random = new Random();
        int index = random.nextInt(array.length);
        Integer result = array[index];
        return result;
    }
    
    /**
     * Return a random String from the String array. 
     */
    public static String randomString(String[] array) {
        Random random = new Random();
        int index = random.nextInt(array.length);
        String result = array[index];
        return result;
    }
    
    /**
     * Return a randomly chosen element from the array. This allows any array of
     * any type of objects to be passed as a parameter with the same type for
     * the return.
     * 
     * Note where the generic type parameter <T> needs to be placed.
     */
    public static <T> T randomElement(T[] array) {
        Random random = new Random();
        int index = random.nextInt(array.length);
        T result = array[index];
        return result;
    }

    public static boolean lessThanInteger(Integer object1, Integer object2) {
        return object1.compareTo(object2) < 0;
    }
    
    public static boolean lessThanString(String object1, String object2) {
        return object1.compareTo(object2) < 0;
    }
    
    /**
     * Return true if the first object is less than the second object.
     * 
     * Note where the generic type parameter <T extends Comparable<T>> needs to
     * be placed.
     * 
     * T extends Comparable is needed to ensure that the type implements the
     * compareTo method.
     * 
     * T extends Comparable<T> is safer as it requires the compareTo method to
     * be implemented generically.
     */
    public static <T extends Comparable<T>> boolean lessThan(T object1,
            T object2) {
        return object1.compareTo(object2) < 0;
    }
}
