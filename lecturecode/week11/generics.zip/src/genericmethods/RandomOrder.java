package genericmethods;
import java.util.*;

public class RandomOrder<E> implements Iterable<E> {
    private ArrayList<E> shuffledList;
    
    public RandomOrder(List<E> list) {
        shuffledList = new ArrayList<E>(list);
        Collections.shuffle(shuffledList);
    }
    
    public RandomOrder(E[] array) {
        shuffledList = arrayToList(array);
        Collections.shuffle(shuffledList);
    }
    
    public Iterator<E> iterator() {
        return shuffledList.iterator();
    }

    public static void main(String[] args) {
        Integer[] iarray = {2, 3, 5, 7, 11, 13, 17, 19};
        String[] sarray = {"aa", "bb", "cc", "xx", "yy", "zz"};
        List<Integer> ilist = arrayToList(iarray);
        List<String> slist = arrayToList(sarray);
        
        for (Integer a : new RandomOrder<Integer>(iarray))
            System.out.print(a + " ");
        System.out.println();
        
        for (String s : new RandomOrder<String>(sarray))
            System.out.print(s + " ");
        System.out.println();
    
        for (Integer a : new RandomOrder<Integer>(ilist))
            System.out.print(a + " ");
        System.out.println();
        
        for (String s : new RandomOrder<String>(slist))
            System.out.print(s + " ");
        System.out.println();
    
        
    }
    
    public static <V> ArrayList<V> arrayToList(V[] array) {
        ArrayList<V> list = new ArrayList<V>();
        for (V element : array) {
            list.add(element);
        }
        return list;
    }
    
    
}
