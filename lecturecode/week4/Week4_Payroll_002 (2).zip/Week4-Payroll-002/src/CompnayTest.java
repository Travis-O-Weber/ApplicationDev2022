/**
 * 
 * @author CS 3443
 *
 */
public class CompnayTest {
	
	public static void main(String[] args) {
		
		// Create a company
		Company ourCompany = new Company("CS Company", 10);		
		ourCompany.loadEmployeesFromFile("data/emplyees.csv");
	}
}
