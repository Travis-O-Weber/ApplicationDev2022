import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

/**
 * 
 * @author CS 3443
 *
 */
public class Company {

	// Add Attributes
	private String name;
	private String type;
	private ArrayList<Employee> employees;

	// Add Constructors
	public Company(String name, int numOfEmployees) {
		this.name = name;
		this.employees = new ArrayList<Employee>();		
	}

	public void loadEmployeesFromFile(String filename) {

		Scanner scan = null;

		try {
			scan = new Scanner(new File(filename));
			Employee temp = null;
			if (scan != null) {
				while(scan.hasNextLine()) {
					String record = scan.nextLine();
					String[] data = record.split(",");

					if(data[0].equals("S")) {
						temp = new SalaryEmployee(data[1], data[2], 
								data[3], Double.parseDouble(data[4]));					
					}
				else {
					temp = new HourlyEmployee(data[1], data[2], 
							data[3], Double.parseDouble(data[4]), Double.parseDouble(data[4]));
				}

				this.addEmployee(temp);
			}

		}	
	}
	catch (IOException e){
		//
		e.printStackTrace();

	}




}


// Add toString()

// Add Getters and Setters
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public ArrayList<Employee> getEmployees() {
	return employees;
}

public void setEmployees(ArrayList<Employee> employees) {
	this.employees = employees;
}

public void addEmployee(Employee newEmployee) {		
	this.employees.add(newEmployee);	
}
}
