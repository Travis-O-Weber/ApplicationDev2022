/**
 * 
 * @author CS 3443
 *
 */
public abstract class Employee {
		
	// Add Attributes
	private String name;
	private String title;
	private String hireDate;
	
	// Add Constructors
	public Employee(String name, String title, String hireDate) {
		this.name = name;
		this.title = title;
		this.hireDate = hireDate;

		
	}
	
	// Add toString()
	
	// Add Getters and Setters
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return
	 */
	public String getHireDate() {
		return hireDate;
	}
	/**
	 * @param hireDate
	 */
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

}
