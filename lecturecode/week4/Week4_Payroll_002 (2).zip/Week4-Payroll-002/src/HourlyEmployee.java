
public class HourlyEmployee extends Employee {


	// Add Attributes
	private double pay;
	private double hrsPerWeek;


	public HourlyEmployee(String name, String title, String hireDate, double pay, double hrsPerWeek) {
		super(name, title, hireDate);
		this.pay = pay; 
		this.hrsPerWeek = hrsPerWeek;
	}


	public double getPay() {
		return pay;
	}


	public void setPay(double pay) {
		this.pay = pay;
	}


	public double getHrsPerWeek() {
		return hrsPerWeek;
	}


	public void setHrsPerWeek(double hrsPerWeek) {
		this.hrsPerWeek = hrsPerWeek;
	}



}
