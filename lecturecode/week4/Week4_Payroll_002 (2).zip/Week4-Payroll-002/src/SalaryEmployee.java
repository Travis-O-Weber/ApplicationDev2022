/**
 * 
 * @author CS
 *
 */
public class SalaryEmployee extends Employee{
	
	private double annualSalary;
	
	public SalaryEmployee(String name, String title, String hireDate, double annualSalary) {
		super(name, title, hireDate);
		this.annualSalary = annualSalary;		
	}

	public double getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}
	

}
