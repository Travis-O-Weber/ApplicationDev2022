
public class AccountTest {
	
	public static void main(String[] args) {
		
		
		Bank myBank = new Bank("CS3443", 10);
		
			
		Account account1 = new Account("Alex");
		Account account2 = new Account("Adam");
		
		Account[] accounts = new Account[10];
		
		//Account[] accounts = new Account[10];
		
		//myBank.addAccount(account1);
		
		//accounts[0] = account1;
		//accounts[1] = account2;
		
		myBank.setAccounts(accounts);
		
		myBank.addAccount(account1);
		
		myBank.toString();
				
		System.out.println(myBank);
				
		System.out.println(account1);
		
		account1.setName("Sam");
		account1.equals(account2);
		
		if("Hi".equals("Hello")) {
			
		}
		
		
	}

}
