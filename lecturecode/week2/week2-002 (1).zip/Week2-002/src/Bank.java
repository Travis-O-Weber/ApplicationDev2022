/**
 * 
 * @author  
 *
 */
public class Bank {
	
	private String name;
	private Account[] accounts;
	private int govID = 0;
	
	
	public Bank(String bankName, int numOfAccounts) {
		name = bankName;
		accounts = new Account[numOfAccounts];		
	}
	
	public void addAccount(Account account) {		
		for (int i = 0; i < accounts.length; i++) {
			if(accounts[i] == null) {
				accounts[i] = account;
				break; // return
			}
		}		
	}
	
	// Override 
	public String toString() {
		
		return "Bank " + this.name + " has " + this.accounts.length + " accounts";
		
	}
	
	public boolean equals(Bank otherBank) {
		
		return this.govID == otherBank.getGovID();		
		//return this.name.equals(otherBank.getName());

	}
	
	private int getGovID() {
		// TODO Auto-generated method stub
		return this.govID;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Account[] getAccount() {
		return accounts;
	}
	
	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
	
	
	

}
